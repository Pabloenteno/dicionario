const openModalButtons = document.querySelectorAll(".open-modal");
const closeModalButtons = document.querySelectorAll(".close-modal");
const modals = document.querySelectorAll(".modal");
const fades = document.querySelectorAll(".fade");
 
const toggleModal = (index) => {
    [modals[index], fades[index]].forEach((el) => el.classList.toggle("hide"));
};
 
openModalButtons.forEach((button, index) => {
    button.addEventListener("click", () => toggleModal(index));
});
 
closeModalButtons.forEach((button, index) => {
    button.addEventListener("click", () => toggleModal(index));
});